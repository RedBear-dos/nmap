---
name: Npcap bug report
about: Report an issue with Npcap
labels: Npcap
assignees: ''
---
**NOTE: Npcap issues have moved to [the Npcap repository](https://github.com/nmap/npcap/issues/)**. Please open your issue there instead.
